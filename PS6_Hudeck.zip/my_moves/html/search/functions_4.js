var searchData=
[
  ['wave',['wave',['../class_my__moves.html#a7774793fbc25151671db5b3817bd3686',1,'My_moves']]]
];
