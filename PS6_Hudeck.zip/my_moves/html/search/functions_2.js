var searchData=
[
  ['raisehand',['raiseHand',['../class_my__moves.html#a7c9f470f9ea88e483ea906d00d75e169',1,'My_moves']]]
];
