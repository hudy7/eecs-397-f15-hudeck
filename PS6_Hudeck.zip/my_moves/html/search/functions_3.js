var searchData=
[
  ['slapbeerofftable',['slapBeerOffTable',['../class_my__moves.html#a1f1243ffc0ee1e770a05ba645a251cf4',1,'My_moves']]]
];
